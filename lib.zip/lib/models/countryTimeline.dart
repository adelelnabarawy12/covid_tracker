class CountryTimeline{
  String date;
  CountryTimelineItem countryTimelineItem;
  CountryTimeline({this.date, this.countryTimelineItem});
}

class CountryTimelineItem{
  int new_daily_cases;
  int new_daily_deaths;
  int total_recoveries;

  CountryTimelineItem({
    this.new_daily_cases,
    this.new_daily_deaths,
    this.total_recoveries,
  });
}

