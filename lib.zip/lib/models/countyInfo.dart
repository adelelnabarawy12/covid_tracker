class Country_Info{
  String total_cases;
  String total_recovered;
  String total_unresolved;
  String total_deaths;
  String total_new_cases_today;
  String total_new_deaths_today;
  String total_active_cases;
  String total_serious_cases;
  String total_danger_rank;

  Country_Info(
    {
      this.total_cases,
      this.total_recovered,
      this.total_unresolved,
      this.total_deaths,
      this.total_new_cases_today,
      this.total_new_deaths_today,
      this.total_active_cases,
      this.total_serious_cases,
      this.total_danger_rank,
    }
  );
}