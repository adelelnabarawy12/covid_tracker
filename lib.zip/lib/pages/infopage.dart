import 'package:flutter/material.dart';
import './homepage_sections/headerSection.dart';
import './infopage_sections/firstSection.dart';
import './infopage_sections/secondSection.dart';


class InfoPage extends StatefulWidget {
  @override
  _InfoPageState createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                HeaderSection('coronadr.svg', 220.0, -10, "Let's To Know\nAbout Covid-19!"),
                Positioned(
                  top: 25,
                  left: 0,
                  child: IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.white,),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
              ],
            ),
            Title('Symptomps'),
            FirstSection(),
            Title('Prevention'),
            SecondSection()
          ],
        ),
      )
    );
  }
}


class Title extends StatelessWidget {
  String _title;
  Title(this._title);
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.only(left: 15, bottom: 15),
      child: Text(
        _title,
        style: TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 16.0,
          letterSpacing: 1.2,
        ),
      )
    );
  }
}



