import 'package:flutter/material.dart';
import 'package:flutter_app/globals.dart';


class SearchSection extends StatefulWidget {
  
  List<String> _items;
  SearchSection(this._items);
  @override
  State createState() {
    return _SearchSectionState(_items);
  }
}

class _SearchSectionState extends State<SearchSection> {
  List<String> _items;
  _SearchSectionState(this._items);
  String _dropDownValue;
  @override
  void initState() {
    _dropDownValue = _items[0];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        color: Colors.white,
        boxShadow: [BoxShadow(blurRadius: 5, color: Colors.black12)],
      ),
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Stack(
        children: <Widget>[
          DropdownButton<String>(
            isExpanded: true,
            icon: Icon(Icons.keyboard_arrow_down, color: Colors.blue,),
            underline: SizedBox(),
            items: _items
                .map((item) => DropdownMenuItem<String>(
                      child: Row(
                        children: <Widget>[
                          Text(getCountryName(item)),
                          Spacer(),
                          Image(image: ExactAssetImage(getCountryFlag(item)))
                        ],
                      ),
                      value: item,
                    ))
                .toList(),
            onChanged: (val) {
              setState(() {
                _dropDownValue = currentCountry = val;
                isLoading = true;
              });
            }),

          Positioned.fill(
            child: Align(
              alignment: Alignment.centerLeft,
              child: Row(
                children: <Widget>[
                  Icon(Icons.location_on, color: Colors.blue,size: 18,),
                  SizedBox(width: 10,),
                  Text(
                    getCountryName(_dropDownValue),
                    style: TextStyle(fontWeight: FontWeight.w600, letterSpacing: 1.2, fontSize: 18),
                  ),
                  Spacer(),
                  Image(image: ExactAssetImage(getCountryFlag(_dropDownValue))),
                  SizedBox(width: 30,)
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
