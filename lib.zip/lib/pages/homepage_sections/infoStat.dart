import 'package:flutter/material.dart';

class InfoStat extends StatelessWidget {
  String _title;
  String _val;
  Color _mainColor;
  Color _accentColor;
  InfoStat(this._title, this._val, this._mainColor, this._accentColor);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(5),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _accentColor,
            ),
            child: Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.transparent,
                border: Border.all(
                  width: 2,
                  color: _mainColor
                )
              ),
            ),
          ),
          SizedBox(height: 5,),
          Text(
            _val,
            style: TextStyle(
              color: _mainColor,
              fontSize: 25,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2
            ),
          ),
          SizedBox(height: 5,),
          Text(
            _title,
            style: TextStyle(
              color: Colors.grey.shade400,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2
            ),
          ),
        ],
      ),
    );
  }
}
