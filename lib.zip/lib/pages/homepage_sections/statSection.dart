import 'package:flutter/material.dart';
import './infoStat.dart';


class StatSection extends StatefulWidget {
  StatSectionModel statSectionModel;
  StatSection(this.statSectionModel);
  @override
  _StatSectionState createState() => _StatSectionState(statSectionModel);
}

class _StatSectionState extends State<StatSection> {
  StatSectionModel statSectionModel;
  _StatSectionState(this.statSectionModel);
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            blurRadius: 2,
            color: Colors.black12,
          )
        ]
      ),
      padding: EdgeInsets.symmetric(vertical: 20),
      margin: EdgeInsets.only(left: 10, right: 10, bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          InfoStat('Infected', statSectionModel.infected, Colors.orange, Colors.orangeAccent.withAlpha(100)),
          InfoStat('Death', statSectionModel.death, Colors.red, Colors.redAccent.withAlpha(100)),
          InfoStat('Recovered', statSectionModel.recovered, Colors.green, Colors.greenAccent.withAlpha(100)),
        ],
      ),
    );
  }
}

class StatSectionModel {
  String infected;
  String recovered;
  String death;


  StatSectionModel({this.infected, this.death, this.recovered});

}