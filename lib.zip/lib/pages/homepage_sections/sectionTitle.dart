import 'package:flutter/material.dart';
import 'package:flutter_app/globals.dart';
import 'package:flutter_app/pages/detailspage.dart';


class SectionTitle extends StatelessWidget {
  String _title;
  String _subTitle;
  String _link;

  SectionTitle(this._title, this._subTitle, this._link);
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
      child: Row(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                _title,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.2,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 2,),
              Text(
                _subTitle,
                style: TextStyle(
                  fontSize: 12,
                  letterSpacing: 1.1,
                  color: Colors.grey.shade400
                ),
              )
            ],
          ),
          Spacer(),
          GestureDetector(
            onTap: () { 
              if (_link != ''){
                gotoPage(context, DetailsPage(info));
              }
            },
            child: Text(
               _link,
              style: TextStyle(
                color: Colors.blue,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.2,
                fontSize: 14,
              ),
            ),
          )
        ],
      ),
    );
  }
}
