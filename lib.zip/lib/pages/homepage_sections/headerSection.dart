import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../globals.dart';

class HeaderSection extends StatelessWidget {
  String _img;
  double _imgSize;
  String _title;
  double _left;
  HeaderSection(this._img, this._imgSize, this._left, this._title);
  Widget getImage(){
    if (_img.split('.')[1] == 'svg'){
      return SvgPicture.asset(
        assetsPath + _img,
        alignment: Alignment.bottomLeft,
        width: _imgSize,
      );
    }
    return Image(image: ExactAssetImage(assetsPath + _img,), width: _imgSize, alignment: Alignment.bottomLeft,);
  }
  @override
  Widget build(BuildContext context) {
    return ClipPath(
      clipper: CustomCurveShapeClipper(),
      child: Container(
        padding: EdgeInsets.only(left: 20),
        width: double.infinity,
        height: MediaQuery.of(context).size.height * .4,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [accentColor, deepColor],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          image: DecorationImage(
            image: ExactAssetImage(assetsPath + 'virus.png'),
            fit: BoxFit.contain,
          ),
        ),
        child: Stack(
          children: <Widget>[
            Positioned(
              right: 25,
              top: 75,
              child: Text(
                _title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.4,
                  fontSize: 16.0,
                ),
              ),
            ),
            Positioned(
              left: _left,
              top: 50,
              child: getImage(),
            ),
          ],
        )
      ),
    );
  }
}

class CustomCurveShapeClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = new Path();
    path.lineTo(0, size.height * .8);
    path.quadraticBezierTo(size.width * .5, size.height * 1.1, size.width, size.height * .8);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => true;
}
