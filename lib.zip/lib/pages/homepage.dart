import 'package:flutter/material.dart';
import '../globals.dart';
import './homepage_sections/headerSection.dart';
import './homepage_sections/sectionTitle.dart';
import './homepage_sections/statSection.dart';
import './infopage.dart';
import '../api/country_api.dart';
import 'package:connectivity/connectivity.dart';

class HomePage extends StatefulWidget {

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  API api;
  String _dropDownValue;


  @override
  void initState() {
    api = new API();
    _dropDownValue = currentCountry;
    initInfo();
    super.initState();
  }
  Future<bool> _checkConnectivity() async {
    var result = await Connectivity().checkConnectivity();
    if (result == ConnectivityResult.none){
      return false;
    }
    else {
      return true;
    }
  }
  
  initInfo({String val}) async {
    val = val == null ? currentCountry : val;
    setState(() {
      isLoading = true;
    });
    isConnected = await _checkConnectivity();
    if(isConnected){
      info = await api.getCountryInfo(getUrlStat(val));
      timeline_today = await api.getLastCountryTimeline(getUrlTimeLine(val));
    }
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            HeaderSection('Drcorona.svg', 160.0, 20,'All you need\nis staying at home!'),
            SizedBox(height: 5,),
            Text(
              'Choose Country',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                letterSpacing: 1.3,
                fontSize: 18
              ),
            ),
            WDivder(),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: Colors.white,
                boxShadow: [BoxShadow(blurRadius: 5, color: Colors.black12)],
              ),
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Stack(
                children: <Widget>[
                  DropdownButton<String>(
                    isExpanded: true,
                    icon: Icon(Icons.keyboard_arrow_down, color: Colors.blue,),
                    underline: SizedBox(),
                    items: countries
                        .map((item) => DropdownMenuItem<String>(
                              child: Row(
                                children: <Widget>[
                                  Text(getCountryName(item)),
                                  Spacer(),
                                  Image(image: ExactAssetImage(getCountryFlag(item)))
                                ],
                              ),
                              value: item,
                            ))
                        .toList(),
                    onChanged: (val) {
                      setState(() {
                        _dropDownValue = currentCountry = val;
                        isLoading = true;
                        initInfo(val: val);
                      });
                    }),

                  Positioned.fill(
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Row(
                        children: <Widget>[
                          Icon(Icons.location_on, color: Colors.blue,size: 18,),
                          SizedBox(width: 10,),
                          Text(
                            getCountryName(_dropDownValue),
                            style: TextStyle(fontWeight: FontWeight.w600, letterSpacing: 1.2, fontSize: 18),
                          ),
                          Spacer(),
                          Image(image: ExactAssetImage(getCountryFlag(_dropDownValue))),
                          SizedBox(width: 30,)
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Builder(builder: (context){
              if (isConnected){
                if (isLoading) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 50.0),
                  child: CircularProgressIndicator(),
                );
              }
              return Column(
                children: <Widget>[
                    SectionTitle("Today's Case Update", 'Latest Update For ' + timeline_today.date, 'Show Details'),
                    StatSection(new StatSectionModel(
                      death: timeline_today.countryTimelineItem.new_daily_deaths.abs().toString(),
                      infected: timeline_today.countryTimelineItem.new_daily_cases.abs().toString(),
                      recovered: timeline_today.countryTimelineItem.total_recoveries.abs().toString(),
                    )),
                  ],
                );
              }
              else {
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 20),
                  child: Column(
                    children: <Widget>[
                      Image(
                        image: ExactAssetImage(assetsPath + 'error.png'),
                        width: 170,
                      ),
                      Text(
                        'No Internet',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      )
                    ],
                  ),
                );
              }
              
              }
            ),
            InfoButton(),
          ],
        ),
      )
    );
  }
}



class InfoButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        margin: EdgeInsets.only(top: 10, bottom: 20),
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: MaterialButton(
          minWidth: double.infinity,
          height: 45,
          color: deepColor,
          onPressed: () => gotoPage(context, InfoPage()),
          child: Text(
            'About Covid-19 (Corona Virus)',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2,
            ),
          ),
        ),
      ),
    );
  }
}


class WDivder extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 1,
      color: Colors.black12,
      margin: EdgeInsets.only(left: 20, right: 30, top: 10, bottom: 15),
    );
  }
}

class Loading extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      color: Colors.white,
      child: Center(
        child: Image(
          image: ExactAssetImage(assetsPath + 'load.gif'),
          width: 150,
        ),
      ),
    );
  }
}
