import 'package:flutter/material.dart';
import '../../globals.dart';

class FirstSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          FirstSectionCard('headache.png', 'Headache'),
          FirstSectionCard('caugh.png', 'Caugh'),
          FirstSectionCard('fever.png', 'Fever'),
        ],
      ),
    );
  }
}


class FirstSectionCard extends StatelessWidget {
  String _img;
  String _title;

  FirstSectionCard(this._img, this._title);
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 85,
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 3,
          )
        ]
      ),
      child: Column(
        children: <Widget>[
          Image(image: ExactAssetImage(assetsPath + _img),),
          SizedBox(height: 5,),
          Text(
            _title,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 12.0,
              letterSpacing: 1.2,
            ),
          )
        ],
      ),
    );
  }
}