import 'package:flutter/material.dart';
import '../../globals.dart';

class SecondSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          SecondSectionCard('wear_mask.png', adviceTitle1, adviceText1),
          SecondSectionCard('wash_hands.png', adviceTitle2, adviceText2),
        ],
      ),
    );
  }
}

class SecondSectionCard extends StatelessWidget {
  String _title;
  String _text;
  String _img;
  SecondSectionCard(this._img, this._title, this._text);
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 10, right: 10),
      child: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(15),
                  blurRadius: 3,
                  offset: Offset(5, 5)
                ),
              ]
            ),
            margin: EdgeInsets.only(left: 50, top: 20),
            padding: EdgeInsets.only(left: 80, top: 15, right: 15, bottom: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  _title,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    letterSpacing: 1.2,
                  ),
                ),
                SizedBox(height: 5,),
                Text(
                  _text,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 10,
                    letterSpacing: 1.1,
                  ),
                )
              ],
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Image(
              width: 150,
              height: 155,
              image: ExactAssetImage(assetsPath + _img)
            )
          ),
        ],
      ),
    );
  }
}
