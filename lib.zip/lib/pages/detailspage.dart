import 'package:flutter/material.dart';
import 'package:flutter_app/models/countyInfo.dart';
import '../globals.dart';
import './homepage_sections/headerSection.dart';
import './homepage_sections/statSection.dart';
import './homepage_sections/sectionTitle.dart';



class DetailsPage extends StatefulWidget {
  Country_Info info;
  DetailsPage(this.info);
  @override
  _DetailsPageState createState() => _DetailsPageState(this.info);
}

class _DetailsPageState extends State<DetailsPage> {
  Country_Info info;

  _DetailsPageState(this.info);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                HeaderSection('doctor.png', 140.0, 30, "Let's To Know\nMore Detials!"),
                Positioned(
                  top: 25,
                  left: 0,
                  child: IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.white,),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
              ],
            ),
            SizedBox(height: 5,),
            Text(
              'Country Details',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                letterSpacing: 1.3,
                fontSize: 18
              ),
            ),
            WDivder(),
            SizedBox(height: 10,),
            Container(
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
              margin: EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(5),
                boxShadow: [
                  BoxShadow(
                    blurRadius: 3,
                    color: Colors.black12
                  )
                ]
              ),
              child: Row(
                children: <Widget>[
                  Image(image: ExactAssetImage(getCountryFlag(currentCountry))),
                  SizedBox(width: 5),
                  Text(
                    getCountryName(currentCountry),
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.2,
                    ),
                  ),
                  Spacer(),
                  Text(
                    'Danger Rank: '+info.total_danger_rank,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.2,
                    ),
                  )
                ],
              ),
            ),
            SectionTitle('Total Cases State', 'Latest Update For ' + timeline_today.date, ''),
            StatSection(StatSectionModel(
              death: info.total_deaths,
              infected: info.total_active_cases,
              recovered: info.total_recovered
            )),
            SectionTitle('Cases State Percentage', 'Latest Update For ' + timeline_today.date, ''),
            PercentageSection(info),
          ],
        ),
      ),
    );
  }
}

class WDivder extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 1,
      color: Colors.black12,
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
    );
  }
}



class PercentageSection extends StatefulWidget {
  Country_Info country_info;
  PercentageSection(this.country_info);
  @override
  _PercentageSectionState createState() => _PercentageSectionState(country_info);
}

class _PercentageSectionState extends State<PercentageSection> {
  Country_Info country_info;
  _PercentageSectionState(this.country_info);
  @override
  Widget build(BuildContext context) {
    double infected = (int.parse(country_info.total_active_cases) / int.parse(country_info.total_cases)) * 100;
    double recovered = (int.parse(country_info.total_recovered) / int.parse(country_info.total_cases)) * 100;
    double death = (int.parse(country_info.total_deaths) / int.parse(country_info.total_cases)) * 100;
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            blurRadius: 2,
            color: Colors.black12,
          )
        ]
      ),
      padding: EdgeInsets.symmetric(vertical: 20),
      margin: EdgeInsets.only(left: 10, right: 10, bottom: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          PercentageCard('Infected', infected.floor().toString() + '%', Colors.orange, Colors.orangeAccent.withAlpha(100)),
          PercentageCard('Death', death.ceil().toString() + '%', Colors.red, Colors.redAccent.withAlpha(100)),
          PercentageCard('Recovered', recovered.ceil().toString() + '%', Colors.green, Colors.greenAccent.withAlpha(100)),
        ],
      ),
    );
  }
}

class PercentageCard extends StatelessWidget {
  Color _mainColor;
  Color _accentColor;
  String _title;
  String _val;
  PercentageCard(this._title, this._val, this._mainColor, this._accentColor);
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Text(
            _title,
            style: TextStyle(
              color: Colors.grey.shade400,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2
            ),
          ),
          SizedBox(height: 10,),
          Container(
            alignment: Alignment.center,
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              border: Border.all(
                color: _accentColor,
                width: 7
              )
            ),
            child: Text(
              _val,
              style: TextStyle(
                color: _mainColor,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
