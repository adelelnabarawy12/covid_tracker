
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/countyInfo.dart';
import '../models/countryTimeline.dart';
import 'dart:async';

class API{
  Future<Country_Info> getCountryInfo(String url) async{
    http.Response response = await http.get(
      Uri.encodeFull(url)
    );
    Country_Info info;
    if (response.statusCode == 200){
      var json_data = jsonDecode(response.body);
      var data = json_data['countrydata'][0];
      info = new Country_Info(
        total_active_cases: data['total_active_cases'].toString(), 
        total_danger_rank: data['total_danger_rank'].toString(),
        total_cases: data['total_cases'].toString(),
        total_deaths: data['total_deaths'].toString(),
        total_new_cases_today: data['total_new_cases_today'].toString(),
        total_new_deaths_today: data['total_new_cases_today'].toString(),
        total_recovered: data['total_recovered'].toString(),
        total_serious_cases: data['total_serious_cases'].toString(),
        total_unresolved: data['total_unresolved'].toString()
      );
      return info;
    }
  } 

  Future<List<CountryTimeline>> getCountryTimeline(String url) async {
      List<CountryTimeline> timeline = new List<CountryTimeline>();
      
      http.Response response = await http.get(
        Uri.encodeFull(url),
      );


      if (response.statusCode == 200){
        var json_data = jsonDecode(response.body); 
        var data = json_data['timelineitems'][0];

        data.forEach((k, v) {
          List<String> l = k.toString().split('/');
          if (k.toString() != 'stat'){
            timeline.add(
              CountryTimeline(
                date: l[1] + '/' + l[0] + '/' + '20' + l[2],
                countryTimelineItem: CountryTimelineItem(
                  new_daily_cases: v['new_daily_cases'],
                  new_daily_deaths: v['new_daily_deaths'],
                  total_recoveries: v['total_recoveries']
                )
              )
            );
          }
        });
      }
      print(timeline.last.date);
      return timeline;
    }
Future<CountryTimeline> getLastCountryTimeline(String url) async {
  List<CountryTimeline> timeline = await getCountryTimeline(url);
  return timeline.last;
}


  
}

