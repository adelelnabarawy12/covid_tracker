

import 'package:flutter/material.dart';
import 'package:flutter_app/models/countryTimeline.dart';
import 'package:flutter_app/models/countyInfo.dart';

String assetsPath = 'assets/images/';
String _assetsFlagsPath = 'assets/flags/';


void gotoPage(BuildContext context, Widget widget) => Navigator.of(context).push(MaterialPageRoute(builder: (context) => widget));

List<String> countries = [
  'Egypt-EG',
  'Saudi Arabia-SA',
  'Emarites-AE',
  'Kuwait-KW',
  'Lebanon-LB',
  'Sudan-SD',
  'Algeria-DZ',
  'Oman-OM',
  'Tunisia-TN',
  'Morocco-MA',
  'Iran-IR',
  'Qatar-QA',
  'England-GB',
  'United States-US',
  'Russia-RU',
  'Spain-ES',
  'France-FR',
  'Italy-IT',
  'Germany-DE',
  'Canada-CA',
  'China-CN',
  'Turkey-TR',
];

Country_Info info = new Country_Info(); 

CountryTimeline timeline_today = new CountryTimeline();

String currentCountry = 'Egypt-EG';


Color deepColor = Color(0xFF3383CD);
Color accentColor = Color(0xFF11249F);

String adviceTitle1 = 'Wear Face Mask';
String adviceText1 = 'Since the start of the corona virus outbreak, Some places has fully embraced wearing face masks and any one caught without one risks becoming a social pariah .';

String adviceTitle2 = 'Wash Your Hands';
String adviceText2 = 'These diseases include gastrointestinal inflections such as "Sallomenalla" and respiratory inflections such as "Influenza"';

String _urlStat = 'https://api.thevirustracker.com/free-api?countryTotal=';

String _urlTimeLine = 'https://api.thevirustracker.com/free-api?countryTimeline=';

bool isConnected = true;

String _getCode(String country){
  return country.split('-')[1];
}

String getCountryName(String country){
  return country.split('-')[0];
}

String getUrlStat(String country){
  return _urlStat + _getCode(country);
}

String getUrlTimeLine(String country){
  return _urlTimeLine + _getCode(country);
}


String getCountryFlag(String country){
  return _assetsFlagsPath + _getCode(country).toLowerCase() + '.png';
}

bool isLoading = false;
